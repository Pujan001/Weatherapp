const apiKey = 'YOUR_API_KEY'; // Replace with your OpenWeatherMap API key
const apiUrl = 'https://api.openweathermap.org/data/2.5/weather';

// Function to fetch weather data from the OpenWeatherMap API
async function getWeather() {
    const city = document.getElementById('city-input').value;
    const resultDiv = document.getElementById('weather-result');

    if (!city) {
        alert("Please enter a city name!");
        return;
    }

    try {
        const response = await fetch(`${apiUrl}?q=${city}&appid=${apiKey}&units=metric`);
        const data = await response.json();

        if (data.cod === "404") {
            alert("City not found! Please check the name.");
            return;
        }

        const cityName = data.name;
        const temperature = `${data.main.temp}°C`;
        const humidity = `Humidity: ${data.main.humidity}%`;
        const windSpeed = `Wind Speed: ${data.wind.speed} m/s`;

        document.getElementById('city-name').textContent = `Weather in ${cityName}`;
        document.getElementById('temperature').textContent = `Temperature: ${temperature}`;
        document.getElementById('humidity').textContent = humidity;
        document.getElementById('wind-speed').textContent = windSpeed;

        resultDiv.style.display = 'block';
    } catch (error) {
        console.error('Error fetching weather data:', error);
        alert("An error occurred. Please try again.");
    }
}
